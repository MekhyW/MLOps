def say_hello(event, context):
    return {
        "created_by": "felipe",
        "message": "Hello World!"
    }